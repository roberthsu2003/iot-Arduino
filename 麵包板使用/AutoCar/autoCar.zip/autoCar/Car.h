#ifndef __CAR__
#define __CAR__

#include <arduino.h>
#include "Motor.h"

class Car{
    
  public:
  static Motor leftMotor;
  static Motor rightMotor;
  
  public:
  typedef enum{
    SLOW,
    MIDDLE,
    FAST  
  } Speed;
  
  static void buildCar(byte leftF,byte leftB, byte leftSpeed,byte rightF,byte rightB, byte rightSpeed);
  static void forward(Speed speed);
  static void backward(Speed speed);
  static void leftF();
  static void rightF();
  static void leftB();
  static void rightB();
  static void stop();
};




#endif
