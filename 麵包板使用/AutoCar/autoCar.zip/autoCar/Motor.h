#ifndef __MOTOR__
#define __MOTOR__

#include <arduino.h>


class Motor{
  private:
  byte _forwardPin;
  byte _backwardPin;
  byte _speedPin;

  public:
  Motor();
  Motor(byte f,byte b,byte s);

  void runF(byte speed);
  void runB(byte speed);
  void stop(void);
};




#endif

