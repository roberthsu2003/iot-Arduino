#include "Car.h"

Motor Car::leftMotor;
Motor Car::rightMotor;

 static void Car::buildCar(byte leftF,byte leftB, byte leftSpeed,byte rightF,byte rightB, byte rightSpeed){  
  Car::leftMotor = Motor(leftF,leftB,leftSpeed); 
  Car::rightMotor =Motor(rightF,rightB,rightSpeed);
 }

 static void Car::forward(Speed speed){
  
  switch (speed){
    case Car::SLOW:
      Car::leftMotor.runF(70);
      Car::rightMotor.runF(70);
      break;
      
    case Car::MIDDLE:
      Car::leftMotor.runF(180);
      Car::rightMotor.runF(180);
      break;

    case Car::FAST:
      Car::leftMotor.runF(255);
      Car::rightMotor.runF(255);
      break;
     
    default:
     break;
  }
 }

 static void Car::backward(Speed speed){
  switch (speed){
    case Car::SLOW:
      Car::leftMotor.runB(70);
      Car::rightMotor.runB(70);
      break;
      
    case Car::MIDDLE:
      Car::leftMotor.runB(180);
      Car::rightMotor.runB(180);
      break;

    case Car::FAST:
      Car::leftMotor.runB(255);
      Car::rightMotor.runB(255);
      break;
     
    default:
     break;
  }
 }

 static void Car::stop(){
  Car::leftMotor.stop();
  Car::rightMotor.stop();
 
 }

 static void Car::leftF(){
   Car::leftMotor.runF(70);
   Car::rightMotor.runF(180);
 }
 
 
 static void Car::rightF(){
  Car::leftMotor.runF(180);
  Car::rightMotor.runF(70);
 }


static void Car::leftB(){
  Car::leftMotor.runB(70);
  Car::rightMotor.runB(180);
}

static void Car::rightB(){
  Car::leftMotor.runB(180);
  Car::rightMotor.runB(70);
}

