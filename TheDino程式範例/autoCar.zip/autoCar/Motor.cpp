#include "Motor.h"

Motor::Motor(){
  
}

Motor::Motor(byte f,byte b,byte s){
  _forwardPin = f;
  _backwardPin = b;
  _speedPin = s;
  pinMode(_forwardPin,OUTPUT);
  pinMode(_backwardPin,OUTPUT);
  pinMode(_speedPin,OUTPUT);
}


void Motor::runF(byte speed){
  digitalWrite(_forwardPin,HIGH);
  digitalWrite(_backwardPin,LOW);
  analogWrite(_speedPin,speed);
}
void Motor::runB(byte speed){
   digitalWrite(_forwardPin,LOW);
   digitalWrite(_backwardPin,HIGH);
   analogWrite(_speedPin,speed);
}

void Motor::stop(void){
  analogWrite(_speedPin,0);
  
}

